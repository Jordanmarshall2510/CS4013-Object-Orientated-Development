public class testStock{
	public static void main (String[] args){
		Stock stock1 = new Stock("John Smith", "LKSS");

	}
}