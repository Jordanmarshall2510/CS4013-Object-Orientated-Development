public class testRectangle{
	public static void main (String[] args){
		Rectangle rec1 = new Rectangle();
		System.out.println();
		Rectangle rec2 = new Rectangle(5.5,4);

	}
}