public interface Colorable {

void howToColor();

	public abstract void howToColor();
}