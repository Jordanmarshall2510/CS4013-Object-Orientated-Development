
public class ex1_5 {
	public static void main (String Args[]) {
		
		double answer = (((7.5 * 2.5)-(1.5 * 3))/(35.5 - 2.5));
		System.out.println(answer);
		
	}

}