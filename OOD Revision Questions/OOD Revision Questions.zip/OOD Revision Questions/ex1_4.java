
public class ex1_4 {
	public static void main (String Args[]) {
		
		System.out.println("a\t a*2\t a*3");
		System.out.println("1\t 2\t 3\t");
		System.out.println("2\t 4\t 6\t");
		System.out.println("3\t 6\t 9\t");
		System.out.println("4\t 8\t 12\t");
	}

}