public TestGradeBook{
	public static void main (String args[]){
		Gradebook gradebook1 = new Gradebook ("John Smith", 87);
		Gradebook gradebook2 = new Gradebook ("Jenny Smith", 47);
	}
}